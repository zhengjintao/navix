-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: navix
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `navix_resume_base`
--

DROP TABLE IF EXISTS `navix_resume_base`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `navix_resume_base` (
  `ID` varchar(32) NOT NULL,
  `CTIME` varchar(16) NOT NULL,
  `ETIME` varchar(16) NOT NULL,
  `CUSERNAME` varchar(64) NOT NULL,
  `CUSER` varchar(32) NOT NULL,
  `EUSERNAME` varchar(64) NOT NULL,
  `EUSER` varchar(32) NOT NULL,
  `PSTATE` varchar(2) NOT NULL,
  `PCONTENT` varchar(2000) DEFAULT NULL,
  `USERID` varchar(32) NOT NULL,
  `NAME` varchar(64) NOT NULL,
  `SEX` varchar(2) DEFAULT NULL COMMENT '1男 2女',
  `BIRTHDAY` varchar(16) DEFAULT NULL COMMENT 'birthday',
  `DATEYEAR` varchar(8) DEFAULT NULL COMMENT 'DATEYEAR',
  `DATEMONTH` varchar(8) DEFAULT NULL,
  `REGISTEREDAREA` varchar(16) DEFAULT NULL,
  `REGISTERED` varchar(128) DEFAULT NULL,
  `LIVESTRAREA` varchar(16) DEFAULT NULL,
  `LIVESTR` varchar(128) DEFAULT NULL,
  `QQCODE` varchar(16) DEFAULT NULL,
  `WXCODE` varchar(16) DEFAULT NULL,
  `MOBILECODE` varchar(16) DEFAULT NULL,
  `EMAILCODE` varchar(32) DEFAULT NULL,
  `MARRIAGESTA` varchar(2) DEFAULT NULL COMMENT '1未婚2已婚3离异 ',
  `NATIONALITY` varchar(16) DEFAULT NULL,
  `OTHERTYPE` varchar(32) DEFAULT NULL,
  `OTHERID` varchar(32) DEFAULT NULL,
  `IDCODE` varchar(32) DEFAULT NULL,
  `STUDYABROAD` varchar(2) DEFAULT NULL COMMENT ' 1有 2 无   ',
  `ZZMM` varchar(2) DEFAULT NULL COMMENT '1中共党员(含预备党员) 2团员3群众4民主党派5无党派人士 ',
  `PHOTOID` varchar(32) DEFAULT NULL,
  `DEGREEMAX` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_Reference_70` (`USERID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='navix_Resume';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `navix_resume_base`
--

LOCK TABLES `navix_resume_base` WRITE;
/*!40000 ALTER TABLE `navix_resume_base` DISABLE KEYS */;
INSERT INTO `navix_resume_base` VALUES ('402888ac55fc0e8e0155fc0f2e230000','20160718113141','20160718113141','系统管理员','40288b854a329988014a329a12f30002','系统管理员','40288b854a329988014a329a12f30002','1','','40288b854a329988014a329a12f30002','系统管理员','1','2016-07-14','2015',NULL,NULL,'asdf',NULL,'asdf','','','asdf','adsf','1','','','','','','','','8');
/*!40000 ALTER TABLE `navix_resume_base` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-01-11 23:02:50
